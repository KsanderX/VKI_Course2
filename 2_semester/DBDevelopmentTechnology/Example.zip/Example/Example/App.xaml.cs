﻿using System.Windows;
using Example.Service;
using Microsoft.Extensions.DependencyInjection;

namespace Example
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private readonly IServiceProvider serviceProvider;
        public App()
        {
            var services = new ServiceCollection();
            services.AddScoped<IAuthorizationService, AuthorizationService>();
            services.AddTransient<MainWindow>();
            services.AddTransient<AccountWindow>();
            serviceProvider = services.BuildServiceProvider();
        }

        protected override void OnStartup(StartupEventArgs e)
        {
            var window = serviceProvider.GetRequiredService<MainWindow>();
            window.Show();
        }
    }

}
