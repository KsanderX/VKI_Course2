﻿using Example.DataBase;

namespace Example.ViewModel
{
   public class IndentViewModel
    {
        public Indent SelectedIndent { get; set; }
    }
}
